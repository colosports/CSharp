﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Computer
    {
        private string _name;
        private int _processor;
        private int _ram;
        private int _hdd;

        public string Name
        {
            get { return _name; }
        }
        public int Processor
        {
            get { return _processor; }
            set { _processor = value; }
        }
        public int Ram
        {
            get { return _ram; }
            set { _ram = value; }
        }
        public int Hdd
        {
            get { return _hdd; }
            set { _hdd = value; }
        }
    }
}
