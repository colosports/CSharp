﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Give the computer a name:");
            var Name = Console.ReadLine();

            var SetName = new Computer(Name)
        }
    }
}
