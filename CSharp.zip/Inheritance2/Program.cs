﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance2
{
    class Program
    {
        static void Main(string[] args)
        {
            var human = new Computer("Lenovo");
            tyDesktop.SaveFile("File1");
            Console.WriteLine("{0} has {1} MB remaining", tyDesktop.Name, tyDesktop.Hdd);
        }
    }
}
