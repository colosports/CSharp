﻿using System;

namespace SpaceX
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                var rocket = new Rocket();
                var pencil = new Cargo();

                pencil.Pounds = 120;
                pencil.Doors = 2;
                pencil.Loaded = true;
                rocket.AddCargo(pencil);
                //Console.WriteLine("Your rocket has: {0} cargos", rocket.cargo.Count);

                var satelite = new Cargo();
                satelite.Pounds = 320;
                rocket.AddCargo(satelite, true);
                //Console.WriteLine("Your rocket has: {0} cargos", rocket.Cargo.Count);

                Console.WriteLine("The total weight of cargo is {0} cargos", rocket.CargoWeight());

                var person = new Person();
                var crewMember = new Person("Ty Lieu");


                Console.WriteLine("People in the rocket:" + crewMember.FirstName);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
