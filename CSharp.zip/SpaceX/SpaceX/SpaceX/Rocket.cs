﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceX
{
    class Rocket
    {
        private int _fuel;
        private string _name;
        private List<Cargo> _bayList = new List<Cargo>();

        //public List<Cargo> Cargo
        //{
        //    get { return _cargo; }
        //}

        public void AddCargo(Cargo mainCargo)
        {
            _bayList.Add(mainCargo);
        }

        public void AddCargo(Cargo mainCargo, bool isLoaded)
        {
            AddCargo(mainCargo);
            Console.WriteLine("Cargo Loaded");
        }

        public float CargoWeight()
        {
            float totalWeight = 0;
            foreach (Cargo cargo in _bayList)
            {
                totalWeight += cargo.Pounds;
            }
            return totalWeight;
        }

    }
}
