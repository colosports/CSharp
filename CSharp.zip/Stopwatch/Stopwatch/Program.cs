﻿using System;

namespace Stopwatch
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                
                var stopWatch = new Stopwatch();
                string caseSwitch = "a";
                Console.WriteLine("Press 'a' to start StopWatch. Press 's' to stop StopWatch. Press 'x' to exit StopWatch.");

                do
                {
                    Console.WriteLine("Enter command:");
                    caseSwitch = Console.ReadLine();

                    switch (caseSwitch)
                    {
                        case "a":
                            Console.WriteLine("StopWatch Started!");
                            stopWatch.Start();
                            break;

                        case "s":
                            stopWatch.Stop();
                            //Console.WriteLine("StopWatch Stopped. Time Duration: {0}", stopWatch.Duration);
                            Console.WriteLine("Start Time: {0}. Stop Time {1}. Duration {2}", stopWatch.StartTime, stopWatch.StopTime, stopWatch.Duration);

                            break;

                        case "x":
                            Console.WriteLine("Exit StopWatch.");
                            break;

                        default:
                            Console.WriteLine("Invalid option! Try another letter");
                            break;
                    }

                } while (caseSwitch!="x");

                
                    
                //Console.WriteLine("Start Time: {0}. Stop Time {1}. Duration {2}", stopWatch.StartTime, stopWatch.StopTime, stopWatch.Duration);
                //Console.WriteLine("Time Duration {0}", stopWatch.Duration);


                //Console.WriteLine("\n\nEnter a key to start StopWatch again.");
                //temp = Console.ReadLine();
                //Console.WriteLine("StopWatch Started!");
                //stopWatch.Start();
                //stopWatch.Start();
                //Console.WriteLine("Press Enter key to stop StopWatch.");
                //temp = Console.ReadLine();
                //Console.WriteLine("StopWatch Stopped!");
                //stopWatch.Stop();
                ////Console.WriteLine("Start Time: {0}. Stop Time {1}. Duration {2}", stopWatch.startTime, stopWatch.stopTime, stopWatch.Duration);
                //Console.WriteLine("Time Duration {0}", stopWatch.Duration);
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe.Message);
                //Console.WriteLine("Error: StopWatch already started.");
            }

        }
    }
}
