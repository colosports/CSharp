﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stopwatch
{
    class Stopwatch
    {
        private DateTime _startTime;
        private DateTime _stopTime;
        private Boolean _started  = false;

        public DateTime StartTime
        {
            get { return _startTime; }
        }
        public DateTime StopTime
        {
            get { return _stopTime; }
        }
        public TimeSpan Duration
        {
            get { return (_stopTime - _startTime);  }
        }

        public void Start()
        {
            if (_started == false)
            {
                _startTime = DateTime.Now;
                _started = true;
            }
            else
            {
                throw new InvalidOperationException("Error: StopWatch already started.");
                
            }
        }

        public void Stop()
        {
            if (_started == true)
            {
                _stopTime = DateTime.Now;
                _started = false;
            }
            else
            {
                Console.WriteLine("Your haven't started the StopWatch yet!");
                _startTime = DateTime.Now;
                _stopTime = _startTime;
            }
        }


    }
}
